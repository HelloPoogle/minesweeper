Run the test cases found in JunitTest by executing JunitRunner.
Results are displayed to the console.